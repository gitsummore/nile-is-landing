const broadcaster = new Broadcaster(6000, 'video', 'play', 'stop');

document.getElementById('broadcaster').setAttribute("class", "embed-responsive-item")
