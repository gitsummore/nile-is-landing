const viewer = new Viewer('video', 3000);

document.getElementById('player1').setAttribute("class", "embed-responsive-item")
document.getElementById('player2').setAttribute("class", "embed-responsive-item")
document.getElementById('player3').setAttribute("class", "embed-responsive-item")

document.getElementById('video').firstChild.setAttribute("class", "embed-responsive embed-responsive-16by9")
